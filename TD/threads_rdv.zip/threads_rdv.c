// TD Threads -- Exercice 4
// gcc -o thrdv threads_rdv.c thw.o barx.o -L/usr/X11R6/lib -lX11 -lpthread

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <time.h>

#define nth 3 // nombre de threads � lancer

void initrec();
void detruitrec();
void flushdis();
void drawstr(int,int,char*,int);
void drawrec(int,int,int,int);
void fillrec(int,int,int,int,char*);
void thread_wait(int,int,int);

// -------------------------------------------------------
// --------------------- RENDEZ-VOUS ---------------------
// -------------------------------------------------------

int nbThreadsArrives=0;
pthread_mutex_t mutexRdv;
pthread_cond_t evtRdv;
int iterationRdv=10;

void rdv()
{

	// mutexRdv contr�le l'acc�s � la variable partag�e nbThreadsArrives.
	pthread_mutex_lock(&mutexRdv);

	// nbThreadsArrives compte le nombre de threads qui ont atteint le point de rendez-vous.
	++nbThreadsArrives;

	if(nbThreadsArrives<nth)
		// les nth-1 premiers threads arriv�s doivent attendre.
		pthread_cond_wait(&evtRdv,&mutexRdv);


	// les nth-i�me thread lib�re tous les autres.
	pthread_cond_broadcast(&evtRdv);

	/*
	 * Autre solution (sans broadcast) !
	 *
	if(nbThreadsArrives>0)
		// le thread arriv� en i-�me position lib�re celui arriv� en (i+1)-i�me position.
		pthread_cond_signal(&evtRdv);
	--nbThreadsArrives;
	 *
	 */

	pthread_mutex_unlock(&mutexRdv);

}

// -------------------------------------------------------
// ---------------- BARRES DE CHARGEMENT -----------------
// -------------------------------------------------------

pthread_t threads[nth];

int pasPx=10;
pthread_mutex_t mutexDessin;

pthread_mutex_t sync;
pthread_mutex_t mutexFinThread;
int numeroThreadTermine;
pthread_cond_t evtThreadTermine;

void* th_fonc(void *arg)
{

	// num�ro du thread ex�cut�.
	long numero=(long)arg;

	// coordonn�e y et longueur de la barre.
	int ypos=0, mi=0; int j;

	// nom et couleur de la barre.
	char *nom="_X_", *couleur="yellow";

	switch(numero)
	{
		case 0:
			ypos=100; mi=20; nom="_0_"; couleur="yellow";
			break;
		case 1:
			ypos=135; mi=35; nom="_1_"; couleur="white";
			break;
		case 2:
			ypos=170; mi=35; nom="_2_"; couleur="green";
			break;
	}

	// on dessine la barre de chargement vide. mutexDessin emp�che
	// que deux threads acc�dent en m�me temps aux fonctions de la biblioth�que.
	pthread_mutex_lock(&mutexDessin);
	drawstr(30,ypos+25,nom,strlen(nom));
	drawrec(100,ypos,mi*pasPx,30);
	pthread_mutex_unlock(&mutexDessin);

	for(j=1;j<=mi;++j)
	{

		thread_wait(numero,0,10+rand()%60);

		// on remplie la barre progressivement.
		pthread_mutex_lock(&mutexDessin);
		fillrec(100,ypos+2,j*pasPx,26,couleur);
		pthread_mutex_unlock(&mutexDessin); 

		if(j==iterationRdv)
		{
			// tous les threads s'attendent apr�s iterationRdv (=10) it�rations.
			printf("thread-%d-rdv\n",numero);
			rdv();
			printf("thread-%d-fin-rdv\n",numero);
		}
	}

	pthread_mutex_lock(&mutexDessin);
	flushdis();
	pthread_mutex_unlock(&mutexDessin); 

	// le thread ne peut effectuer un P(sync) que si le thread principal
	// (fonction main) est pr�t, i.e. il attend un �v�nement de type evtThreadTermine.
	pthread_mutex_lock(&sync);

	// mutexFinThread contr�le l'acc�s � la variable partag�e numeroThreadTermine.
	pthread_mutex_lock(&mutexFinThread); // (1)

	// numeroThreadTermine sauvegarde le num�ro du prochain thread qui va se terminer.
	numeroThreadTermine=numero;

	// on envoie un signal evtThreadTermine pour indiquer au thread
	// principal (fonction main) qu'un thread est sur le point de se terminer.
	pthread_cond_signal(&evtThreadTermine); // (2)

  	pthread_mutex_unlock(&mutexFinThread); 
  	return ((void*)(numero+42+mi+ypos));

}


int main()
{

	long i,j; void *val; srand(time(NULL));

	// cr�ation du rectangle rouge.
	initrec();

	// on dessine une marque au lieu de rendez-vous.
	drawrec(100+iterationRdv*pasPx,50,4,180);

	// initialisation des mutex.
  	pthread_mutex_init(&sync,NULL);
	pthread_mutex_init(&mutexFinThread,NULL);	
	pthread_mutex_init(&mutexDessin,NULL);
	pthread_mutex_init(&mutexRdv,NULL);

	// initialisation des variables conditionnelles.
  	pthread_cond_init(&evtThreadTermine,NULL);
	pthread_cond_init(&evtRdv,NULL);

	// cr�ation des threads.
	for(i=0;i<nth;++i)
	{
		printf("main-debut-thread-%d\n",i);
		pthread_create(&threads[i],NULL,th_fonc,(void*)i);
	}

	// on attends la fin des threads.
	for(i=0;i<nth;++i)
	{

		// mutexFinThread contr�le l'acc�s � la variable partag�e numeroThreadTermine.
		pthread_mutex_lock(&mutexFinThread);

		// on est pr�t � recevoir un �v�nement de type evtThreadTermine (� prendre
		// connaissance de la terminaison imminente d'un thread).
		if(i>0) pthread_mutex_unlock(&sync);

		// on attend un �v�nement evtThreadTermine. N'oubliez pas que mutexFinThread
		// est d�bloqu� pendant cette phase d'attente (ce qui permet ici � un des threads
		// de passer (1) et d'emettre un signal (2)) !
		pthread_cond_wait(&evtThreadTermine,&mutexFinThread);

		// on r�cup�re le num�ro du thread qui va se terminer.
    		j=numeroThreadTermine;

  		pthread_mutex_unlock(&mutexFinThread);

		// on attend la terminaison compl�te de ce thread. 
    		pthread_join(threads[j],&val);
    		printf("main-fin-thread-%d-avec-val=%d\n",j,(long)val);

	}

	printf("main-tout-est-termine\n");

	// destruction de la fen�tre et fin du programme.
	detruitrec(); return 0;

}

